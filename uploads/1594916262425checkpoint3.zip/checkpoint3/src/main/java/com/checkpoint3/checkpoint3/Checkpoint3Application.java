package com.checkpoint3.checkpoint3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Checkpoint3Application {

	public static void main(String[] args) {
		SpringApplication.run(Checkpoint3Application.class, args);
	}

}
